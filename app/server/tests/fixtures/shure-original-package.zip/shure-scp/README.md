# Shure SCP 配接源码

源码版本：3aee959ed650。`src/` 内 12 个文件与生成此导出包时的服务器源码逐字一致，SHA256 见 manifest.json。

这是开发用配接源码包，不是服务器迁移备份或可直接安装的插件。当前外部插件安装器和云端库尚未接入。

## 接入

正式入口为 ShureDiscovery、ShureMeterSession 与 ShureControlRouter；legacyReferences 是兼容参考，不是当前控制主入口。须集成到匹配的 r19 宿主，不能作为独立安装包运行。

宿主装配、桥接入口和共享依赖见 manifest.json。保留现有配对/TLS、稳定身份、统一GROUP/CH、原命令日记及持久化；网页经MQTT读取状态，不能直接越过服务器控制设备。

## 模块范围

实际文件、能力键、运行入口、宿主依赖与兼容参考分类均见 manifest.json。现场机身标签注册表、已知设备缓存与安全配置不在导出包内；设备能力未知时不得猜测频段。

## 验证与更新

先做离线报文及隔离网络测试，再在授权范围内进行实机验收。未知值不补零；真实回读不冒充command_id ACK；未知/超时控制不得自动重放。修改源文件后重新生成导出目录并随正式包发布；新增品牌在contracts/brand-plugin-exports.json列出实际源码与能力键，再运行scripts/build-plugin-exports.py。

本包不包含数据库、配对密钥、证书、现场配置、设备状态或遥测记录。RFutils参考项目采用MIT许可；参考与原创实现的说明保留在源码中，未复制RFutils仓库。
